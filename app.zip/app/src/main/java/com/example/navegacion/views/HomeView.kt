package com.example.navegacion.views

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import com.example.navegacion.components.TittleBar
import com.example.navegacion.components.ActionButton
import com.example.navegacion.components.TittleView

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeView(navController : NavController){
    Scaffold (
        topBar = {
             CenterAlignedTopAppBar(
                 title = { TittleBar (name= "Home view" )},
                 colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                     containerColor = Color.Red
                 )
             )
        },
        floatingActionButton = {
            ActionButton()
        }
    ) {
        ContentHomeView()
    }
}

@Composable
fun ContentHomeView() {
    Column {
        TittleView( name = "Home View")
    }
}







